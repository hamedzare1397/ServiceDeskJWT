<script setup>
const items = [
    {title:'کاربران',icon:'mdi-account'}
];
</script>
<template>
    <v-sheet>
        <v-btn>کاربران</v-btn>
    </v-sheet>

</template>
