<template>
<h1>داشبورد</h1>
</template>

<script setup>
</script>

<style scoped>

</style>
