export default {
    badge: 'بسته',
    close: 'بستن',
  }