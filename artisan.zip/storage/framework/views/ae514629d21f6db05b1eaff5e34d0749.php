<?php $__env->startSection('titlePage'); ?>سامانه مدیریت ارزیابی خبر<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js','resources/css/app.css']); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="app">
        <router-view />
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\phpProjects\News\resources\views/spa.blade.php ENDPATH**/ ?>